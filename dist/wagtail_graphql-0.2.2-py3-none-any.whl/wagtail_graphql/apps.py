from django.apps import AppConfig      # pragma: no cover


class ApiConfig(AppConfig):     # pragma: no cover
    name = 'wagtail_graphql'
